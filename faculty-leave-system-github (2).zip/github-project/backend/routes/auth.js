const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcrypt');
const jwt      = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db       = require('../config/db');
const { sendEmail, resetPasswordEmail } = require('../utils/email');
require('dotenv').config();

// ─── helpers ────────────────────────────────────────────────
function ok(res, data, code = 200) {
  return res.status(code).json({ success: true, ...data });
}
function fail(res, message, code = 400) {
  return res.status(code).json({ success: false, message });
}

// ─── FACULTY REGISTER ───────────────────────────────────────
router.post('/faculty/register', async (req, res) => {
  try {
    const { faculty_id, name, email, password, department, phone } = req.body;

    // Validation
    if (!faculty_id || !name || !email || !password)
      return fail(res, 'faculty_id, name, email and password are required');
    if (!/\S+@\S+\.\S+/.test(email))
      return fail(res, 'Invalid email format');
    if (password.length < 8)
      return fail(res, 'Password must be at least 8 characters');

    // Duplicate check
    const [existing] = await db.query(
      'SELECT id FROM faculties WHERE email = ? OR faculty_id = ?',
      [email.toLowerCase().trim(), faculty_id.trim()]
    );
    if (existing.length)
      return fail(res, 'Email or Faculty ID is already registered', 409);

    const hashed = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO faculties (faculty_id, name, email, password, department, phone) VALUES (?,?,?,?,?,?)',
      [faculty_id.trim(), name.trim(), email.toLowerCase().trim(), hashed,
       department ? department.trim() : null,
       phone      ? phone.trim()      : null]
    );

    // Leave balance row for this year
    await db.query(
      'INSERT IGNORE INTO leave_balances (faculty_id, year) VALUES (?, YEAR(NOW()))',
      [result.insertId]
    );

    return ok(res, { message: 'Registration successful! You can now log in.' }, 201);
  } catch (err) {
    console.error('[faculty/register]', err);
    return fail(res, `Registration failed: ${err.message}`, 500);
  }
});

// ─── FACULTY LOGIN ──────────────────────────────────────────
router.post('/faculty/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return fail(res, 'Email and password are required');

    const [rows] = await db.query(
      'SELECT * FROM faculties WHERE email = ? AND is_active = 1',
      [email.toLowerCase().trim()]
    );
    if (!rows.length) return fail(res, 'No account found with this email', 401);

    const faculty = rows[0];
    const match = await bcrypt.compare(password, faculty.password);
    if (!match) return fail(res, 'Incorrect password', 401);

    const token = jwt.sign(
      { id: faculty.id, email: faculty.email, name: faculty.name,
        role: 'faculty', faculty_id: faculty.faculty_id },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    return ok(res, {
      token,
      user: { id: faculty.id, name: faculty.name, email: faculty.email,
              faculty_id: faculty.faculty_id, department: faculty.department }
    });
  } catch (err) {
    console.error('[faculty/login]', err);
    return fail(res, `Login failed: ${err.message}`, 500);
  }
});

// ─── ADMIN REGISTER ─────────────────────────────────────────
router.post('/admin/register', async (req, res) => {
  try {
    const { admin_id, name, email, password, role, department } = req.body;

    if (!admin_id || !name || !email || !password)
      return fail(res, 'admin_id, name, email and password are required');
    if (!/\S+@\S+\.\S+/.test(email))
      return fail(res, 'Invalid email format');
    if (password.length < 8)
      return fail(res, 'Password must be at least 8 characters');

    const [existing] = await db.query(
      'SELECT id FROM admins WHERE email = ? OR admin_id = ?',
      [email.toLowerCase().trim(), admin_id.trim()]
    );
    if (existing.length)
      return fail(res, 'Email or Admin ID is already registered', 409);

    const hashed = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO admins (admin_id, name, email, password, role, department) VALUES (?,?,?,?,?,?)',
      [admin_id.trim(), name.trim(), email.toLowerCase().trim(), hashed,
       ['admin','hod'].includes(role) ? role : 'admin',
       department ? department.trim() : null]
    );

    return ok(res, { message: 'Admin registered successfully! You can now log in.' }, 201);
  } catch (err) {
    console.error('[admin/register]', err);
    return fail(res, `Registration failed: ${err.message}`, 500);
  }
});

// ─── ADMIN LOGIN ─────────────────────────────────────────────
router.post('/admin/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return fail(res, 'Email and password are required');

    const [rows] = await db.query(
      'SELECT * FROM admins WHERE email = ? AND is_active = 1',
      [email.toLowerCase().trim()]
    );
    if (!rows.length) return fail(res, 'No account found with this email', 401);

    const admin = rows[0];
    const match = await bcrypt.compare(password, admin.password);
    if (!match) return fail(res, 'Incorrect password', 401);

    const token = jwt.sign(
      { id: admin.id, email: admin.email, name: admin.name,
        role: admin.role, admin_id: admin.admin_id },
      process.env.JWT_SECRET || 'fallback_secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    return ok(res, {
      token,
      user: { id: admin.id, name: admin.name, email: admin.email,
              admin_id: admin.admin_id, role: admin.role, department: admin.department }
    });
  } catch (err) {
    console.error('[admin/login]', err);
    return fail(res, `Login failed: ${err.message}`, 500);
  }
});

// ─── FACULTY FORGOT PASSWORD ─────────────────────────────────
router.post('/faculty/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return fail(res, 'Email is required');

    const [rows] = await db.query(
      'SELECT * FROM faculties WHERE email = ?', [email.toLowerCase().trim()]
    );
    // Always respond same message to prevent email enumeration
    if (!rows.length)
      return ok(res, { message: 'If this email is registered, a reset link has been sent.' });

    const token  = uuidv4();
    const expiry = new Date(Date.now() + 3600000); // 1 hour
    await db.query(
      'UPDATE faculties SET reset_token = ?, reset_token_expiry = ? WHERE email = ?',
      [token, expiry, email.toLowerCase().trim()]
    );

    const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:5001'}/reset-password.html?token=${token}&type=faculty`;
    const { subject, html } = resetPasswordEmail(rows[0].name, resetLink);
    const sent = await sendEmail({ to: email, subject, html });

    return ok(res, {
      message: sent
        ? 'Password reset link sent to your email.'
        : 'Reset link generated but email could not be sent. Check server email config.'
    });
  } catch (err) {
    console.error('[faculty/forgot-password]', err);
    return fail(res, `Error: ${err.message}`, 500);
  }
});

// ─── ADMIN FORGOT PASSWORD ────────────────────────────────────
router.post('/admin/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return fail(res, 'Email is required');

    const [rows] = await db.query(
      'SELECT * FROM admins WHERE email = ?', [email.toLowerCase().trim()]
    );
    if (!rows.length)
      return ok(res, { message: 'If this email is registered, a reset link has been sent.' });

    const token  = uuidv4();
    const expiry = new Date(Date.now() + 3600000);
    await db.query(
      'UPDATE admins SET reset_token = ?, reset_token_expiry = ? WHERE email = ?',
      [token, expiry, email.toLowerCase().trim()]
    );

    const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:5500'}/reset-password.html?token=${token}&type=admin`;
    const { subject, html } = resetPasswordEmail(rows[0].name, resetLink);
    const sent = await sendEmail({ to: email, subject, html });

    return ok(res, {
      message: sent
        ? 'Password reset link sent to your email.'
        : 'Reset link generated but email could not be sent. Check server email config.'
    });
  } catch (err) {
    console.error('[admin/forgot-password]', err);
    return fail(res, `Error: ${err.message}`, 500);
  }
});

// ─── RESET PASSWORD ──────────────────────────────────────────
router.post('/reset-password', async (req, res) => {
  try {
    const { token, type, password } = req.body;
    if (!token || !password) return fail(res, 'Token and new password are required');
    if (password.length < 8) return fail(res, 'Password must be at least 8 characters');

    const table = type === 'admin' ? 'admins' : 'faculties';
    const [rows] = await db.query(
      `SELECT * FROM ${table} WHERE reset_token = ? AND reset_token_expiry > NOW()`, [token]
    );
    if (!rows.length)
      return fail(res, 'This reset link is invalid or has expired. Please request a new one.', 400);

    const hashed = await bcrypt.hash(password, 10);
    await db.query(
      `UPDATE ${table} SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE reset_token = ?`,
      [hashed, token]
    );

    return ok(res, { message: 'Password reset successfully! Please log in with your new password.' });
  } catch (err) {
    console.error('[reset-password]', err);
    return fail(res, `Error: ${err.message}`, 500);
  }
});

module.exports = router;
