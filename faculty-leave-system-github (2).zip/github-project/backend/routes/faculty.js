const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifyToken, isFaculty } = require('../middleware/auth');
const { sendEmail } = require('../utils/email');

// ── Admin notification email builder ─────────────────────────
function adminNewLeaveEmail(facultyName, facultyId, department, leaveType, fromDate, toDate, totalDays, reason) {
  const fmt = (d) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  return {
    subject: `📋 New Leave Request – ${facultyName} (${leaveType}, ${totalDays}d)`,
    html: `
    <div style="font-family:'Segoe UI',Arial,sans-serif;max-width:580px;margin:auto">
      <div style="background:linear-gradient(135deg,#1abc9c,#16a085);padding:28px 24px;border-radius:10px 10px 0 0;text-align:center">
        <h2 style="color:#fff;margin:0">📋 New Leave Application</h2>
        <p style="color:rgba(255,255,255,.85);margin:6px 0 0;font-size:13px">A faculty member has submitted a leave request</p>
      </div>
      <div style="background:#fff;border:1px solid #e4e9f0;padding:28px;border-radius:0 0 10px 10px">
        <span style="display:inline-block;background:#fff3cd;color:#856404;border:1px solid #ffc107;border-radius:20px;padding:4px 14px;font-size:12px;font-weight:700;margin-bottom:18px">⏳ Pending Review</span>
        <p style="color:#1a1f36;font-size:14px">A new leave application requires your attention.</p>
        <table style="width:100%;border-collapse:collapse;margin:18px 0">
          <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;width:40%;color:#7a8499">Faculty Name</td><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:700">${facultyName}</td></tr>
          <tr><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">Faculty ID</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${facultyId}</td></tr>
          <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">Department</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${department || '—'}</td></tr>
          <tr><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">Leave Type</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${leaveType}</td></tr>
          <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">From</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${fmt(fromDate)}</td></tr>
          <tr><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">To</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${fmt(toDate)}</td></tr>
          <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;color:#7a8499">Total Days</td><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:700">${totalDays} day${totalDays > 1 ? 's' : ''}</td></tr>
        </table>
        <div style="background:#fffbf0;border:1px solid #ffe08a;border-radius:8px;padding:12px 16px;margin-bottom:22px">
          <b style="color:#856404;display:block;margin-bottom:4px">Reason for Leave:</b>
          <span style="color:#5a4a00;font-size:13px">${reason}</span>
        </div>
        <div style="text-align:center;margin-bottom:20px">
          <a href="${process.env.FRONTEND_URL || 'http://localhost:5500'}/admin-dashboard.html"
             style="background:#1abc9c;color:#fff;text-decoration:none;padding:12px 30px;border-radius:8px;font-weight:700;font-size:14px;display:inline-block">
            Review Application →
          </a>
        </div>
        <p style="color:#999;font-size:12px;text-align:center">Log in to the Admin Dashboard to approve or reject this request.</p>
      </div>
    </div>`
  };
}

// Apply for leave
router.post('/apply', verifyToken, isFaculty, async (req, res) => {
  try {
    const { leave_type, from_date, to_date, reason } = req.body;
    if (!leave_type || !from_date || !to_date || !reason)
      return res.status(400).json({ success: false, message: 'All fields are required' });

    const from = new Date(from_date);
    const to   = new Date(to_date);
    if (to < from)
      return res.status(400).json({ success: false, message: 'To date must be after from date' });

    const total_days = Math.ceil((to - from) / (1000 * 60 * 60 * 24)) + 1;

    // Check for overlapping leaves
    const [overlap] = await db.query(
      `SELECT id FROM leave_applications WHERE faculty_id=? AND status != 'Rejected' AND (from_date <= ? AND to_date >= ?)`,
      [req.user.id, to_date, from_date]
    );
    if (overlap.length > 0)
      return res.status(409).json({ success: false, message: 'You already have a leave application overlapping these dates' });

    // Insert leave
    await db.query(
      'INSERT INTO leave_applications (faculty_id, leave_type, from_date, to_date, total_days, reason) VALUES (?,?,?,?,?,?)',
      [req.user.id, leave_type, from_date, to_date, total_days, reason]
    );

    // ── Notify all admins via email ──────────────────────────
    try {
      const [facRows] = await db.query(
        'SELECT name, faculty_id, department FROM faculties WHERE id=?',
        [req.user.id]
      );
      const faculty = facRows[0];

      const [admins] = await db.query(
        'SELECT name, email FROM admins WHERE is_active=1'
      );

      for (const admin of admins) {
        const { subject, html } = adminNewLeaveEmail(
          faculty.name,
          faculty.faculty_id,
          faculty.department,
          leave_type,
          from_date,
          to_date,
          total_days,
          reason
        );
        await sendEmail({ to: admin.email, subject, html });
        console.log(`📧 Admin notified: ${admin.email}`);
      }
    } catch (emailErr) {
      // Email failure must NOT block the leave submission
      console.error('⚠️  Admin email notification failed:', emailErr.message);
    }
    // ── End email block ──────────────────────────────────────

    res.status(201).json({ success: true, message: 'Leave application submitted successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get leave history
router.get('/history', verifyToken, isFaculty, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT la.*, a.name as approved_by FROM leave_applications la
       LEFT JOIN admins a ON la.admin_id = a.id
       WHERE la.faculty_id=? ORDER BY la.applied_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get leave status
router.get('/status', verifyToken, isFaculty, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT la.*, a.name as approved_by FROM leave_applications la
       LEFT JOIN admins a ON la.admin_id = a.id
       WHERE la.faculty_id=? ORDER BY la.applied_at DESC`,
      [req.user.id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get leave balance
router.get('/balance', verifyToken, isFaculty, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM leave_balances WHERE faculty_id=? AND year=YEAR(NOW())',
      [req.user.id]
    );
    if (!rows.length) {
      await db.query(
        'INSERT INTO leave_balances (faculty_id, year) VALUES (?, YEAR(NOW()))',
        [req.user.id]
      );
      const [newRows] = await db.query(
        'SELECT * FROM leave_balances WHERE faculty_id=? AND year=YEAR(NOW())',
        [req.user.id]
      );
      return res.json({ success: true, data: newRows[0] });
    }
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Get faculty profile
router.get('/profile', verifyToken, isFaculty, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT id,faculty_id,name,email,department,phone,created_at FROM faculties WHERE id=?',
      [req.user.id]
    );
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;