const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { verifyToken, isAdmin } = require('../middleware/auth');
const { sendEmail, leaveApprovalEmail } = require('../utils/email');

// Get all leave applications
router.get('/leaves', verifyToken, isAdmin, async (req, res) => {
  try {
    const { status } = req.query;
    let query = `SELECT la.*, f.name as faculty_name, f.faculty_id as fac_id, f.department, f.email as faculty_email,
                 a.name as approved_by FROM leave_applications la
                 JOIN faculties f ON la.faculty_id = f.id
                 LEFT JOIN admins a ON la.admin_id = a.id`;
    const params = [];
    if (status) { query += ' WHERE la.status=?'; params.push(status); }
    query += ' ORDER BY la.applied_at DESC';
    const [rows] = await db.query(query, params);
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Approve or Reject leave
router.put('/leaves/:id', verifyToken, isAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, admin_remarks } = req.body;
    if (!['Approved','Rejected'].includes(status)) return res.status(400).json({ success: false, message: 'Invalid status' });

    // Get leave details for email
    const [leaveRows] = await db.query(
      `SELECT la.*, f.name as faculty_name, f.email as faculty_email FROM leave_applications la
       JOIN faculties f ON la.faculty_id = f.id WHERE la.id=?`, [id]
    );
    if (!leaveRows.length) return res.status(404).json({ success: false, message: 'Leave not found' });

    const leave = leaveRows[0];
    await db.query(
      'UPDATE leave_applications SET status=?, admin_id=?, admin_remarks=? WHERE id=?',
      [status, req.user.id, admin_remarks || null, id]
    );

    // Update leave balance if approved
    if (status === 'Approved') {
      const typeMap = { 'Casual Leave': 'casual', 'Medical Leave': 'medical', 'Emergency Leave': 'emergency' };
      const col = typeMap[leave.leave_type];
      if (col) {
        await db.query(
          `UPDATE leave_balances SET ${col}_used = ${col}_used + ? WHERE faculty_id=? AND year=YEAR(?)`,
          [leave.total_days, leave.faculty_id, leave.from_date]
        );
      }
    }

    // Send email notification
    const { subject, html } = leaveApprovalEmail(
      leave.faculty_name, leave.leave_type,
      leave.from_date, leave.to_date,
      status, admin_remarks
    );
    await sendEmail({ to: leave.faculty_email, subject, html });

    res.json({ success: true, message: `Leave ${status} successfully` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Dashboard stats
router.get('/stats', verifyToken, isAdmin, async (req, res) => {
  try {
    const [[{ total }]] = await db.query('SELECT COUNT(*) as total FROM leave_applications');
    const [[{ pending }]] = await db.query("SELECT COUNT(*) as pending FROM leave_applications WHERE status='Pending'");
    const [[{ approved }]] = await db.query("SELECT COUNT(*) as approved FROM leave_applications WHERE status='Approved'");
    const [[{ rejected }]] = await db.query("SELECT COUNT(*) as rejected FROM leave_applications WHERE status='Rejected'");
    const [[{ faculties }]] = await db.query('SELECT COUNT(*) as faculties FROM faculties WHERE is_active=1');
    res.json({ success: true, data: { total, pending, approved, rejected, faculties } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
