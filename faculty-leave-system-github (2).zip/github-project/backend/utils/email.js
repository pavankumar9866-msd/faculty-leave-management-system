const nodemailer = require('nodemailer');
const db = require('../config/db');
require('dotenv').config();

let transporter = null;

function getTransporter() {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host:   process.env.EMAIL_HOST || 'smtp.gmail.com',
      port:   parseInt(process.env.EMAIL_PORT) || 587,
      secure: false,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      },
      tls: { rejectUnauthorized: false }
    });
  }
  return transporter;
}

const sendEmail = async ({ to, subject, html }) => {
  if (!process.env.EMAIL_USER || process.env.EMAIL_USER === 'your_gmail@gmail.com') {
    console.warn('⚠️  Email not configured — skipping send. Set EMAIL_USER and EMAIL_PASS in .env');
    return false;
  }

  try {
    const info = await getTransporter().sendMail({
      from:    process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to,
      subject,
      html
    });

    console.log(`✅ Email sent to ${to} | MessageId: ${info.messageId}`);

    await db.query(
      'INSERT INTO email_logs (recipient_email, subject, body, status) VALUES (?,?,?,?)',
      [to, subject, html, 'sent']
    ).catch(() => {});

    return true;

  } catch (err) {
    console.error(`❌ Email FAILED to ${to}:`, err.message);

    await db.query(
      'INSERT INTO email_logs (recipient_email, subject, body, status) VALUES (?,?,?,?)',
      [to, subject, html, 'failed']
    ).catch(() => {});

    return false;
  }
};

const leaveApprovalEmail = (facultyName, leaveType, fromDate, toDate, status, remarks) => ({
  subject: `Leave ${status} — ${leaveType}`,
  html: `
  <div style="font-family:Arial,sans-serif;max-width:580px;margin:auto">
    <div style="background:linear-gradient(135deg,#1a9fa8,#3b4ec8);padding:28px 24px;border-radius:10px 10px 0 0;text-align:center">
      <h2 style="color:#fff;margin:0">Faculty Leave Management System</h2>
    </div>
    <div style="background:#fff;border:1px solid #e4e9f0;padding:28px;border-radius:0 0 10px 10px">
      <h3 style="color:${status === 'Approved' ? '#27ae60' : '#e74c3c'}">Leave ${status}</h3>
      <p>Dear <strong>${facultyName}</strong>,</p>
      <p>Your leave application has been <strong style="color:${status === 'Approved' ? '#27ae60' : '#e74c3c'}">${status}</strong>.</p>
      <table style="width:100%;border-collapse:collapse;margin:18px 0">
        <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600;width:40%">Leave Type</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${leaveType}</td></tr>
        <tr><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600">From</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${fromDate}</td></tr>
        <tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600">To</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${toDate}</td></tr>
        <tr><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600">Status</td><td style="padding:10px 14px;border:1px solid #e4e9f0;color:${status === 'Approved' ? '#27ae60' : '#e74c3c'};font-weight:700">${status}</td></tr>
        ${remarks ? `<tr style="background:#f7faff"><td style="padding:10px 14px;border:1px solid #e4e9f0;font-weight:600">Remarks</td><td style="padding:10px 14px;border:1px solid #e4e9f0">${remarks}</td></tr>` : ''}
      </table>
      <p style="color:#999;font-size:12px">This is an automated message. Please do not reply.</p>
    </div>
  </div>`
});

const resetPasswordEmail = (name, resetLink) => ({
  subject: 'Password Reset — Faculty Leave System',
  html: `
  <div style="font-family:Arial,sans-serif;max-width:520px;margin:auto">
    <div style="background:linear-gradient(135deg,#1a9fa8,#3b4ec8);padding:28px;border-radius:10px 10px 0 0;text-align:center">
      <h2 style="color:#fff;margin:0">Password Reset</h2>
    </div>
    <div style="background:#fff;border:1px solid #e4e9f0;padding:28px;border-radius:0 0 10px 10px">
      <p>Dear <strong>${name}</strong>,</p>
      <p>Click the button below to reset your password. This link expires in <strong>1 hour</strong>.</p>
      <div style="text-align:center;margin:28px 0">
        <a href="${resetLink}" style="background:linear-gradient(135deg,#1a9fa8,#3b4ec8);color:#fff;padding:13px 28px;border-radius:8px;text-decoration:none;font-weight:700;font-size:15px">Reset My Password</a>
      </div>
      <p style="color:#999;font-size:12px">If you didn't request this, ignore this email.</p>
      <p style="color:#bbb;font-size:11px;word-break:break-all">Link: ${resetLink}</p>
    </div>
  </div>`
});

module.exports = { sendEmail, leaveApprovalEmail, resetPasswordEmail };