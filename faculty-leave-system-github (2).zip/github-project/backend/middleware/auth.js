const jwt = require('jsonwebtoken');
require('dotenv').config();

const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ success: false, message: 'Access token required' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid or expired token' });
  }
};

const isFaculty = (req, res, next) => {
  if (req.user.role !== 'faculty') return res.status(403).json({ success: false, message: 'Faculty access only' });
  next();
};

const isAdmin = (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.role !== 'hod') return res.status(403).json({ success: false, message: 'Admin access only' });
  next();
};

module.exports = { verifyToken, isFaculty, isAdmin };
