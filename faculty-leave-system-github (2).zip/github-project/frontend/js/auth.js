// ── Change this if your backend runs on a different port ──────
const API = 'http://localhost:5000/api';

// ── Alert helper ──────────────────────────────────────────────
function showAlert(msg, type = 'info') {
  const el = document.getElementById('alert');
  if (!el) return;
  const icons = { success:'circle-check', danger:'circle-xmark', info:'circle-info', warning:'triangle-exclamation' };
  el.className = `alert alert-${type} show`;
  el.innerHTML = `<i class="fa-solid fa-${icons[type]||'circle-info'}"></i> ${msg}`;
  if (type === 'success') setTimeout(() => el.classList.remove('show'), 5000);
}

function showErr(id) { document.getElementById(id)?.classList.add('show'); }
function hideErr(id) { document.getElementById(id)?.classList.remove('show'); }

// ── Token helpers ─────────────────────────────────────────────
function getToken() { return localStorage.getItem('token'); }
function getUser()  { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } }
function getRole()  { return localStorage.getItem('role'); }

function logout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

function requireAuth(expectedRole) {
  const token = getToken();
  const role  = getRole();
  if (!token) { window.location.href = 'index.html'; return false; }
  if (expectedRole && role !== expectedRole) { window.location.href = 'index.html'; return false; }
  return true;
}

// ── Fetch wrapper with auth header ────────────────────────────
async function apiFetch(endpoint, options = {}) {
  const token   = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers
  };
  try {
    const res = await fetch(`${API}${endpoint}`, { ...options, headers });

    // Token expired or invalid
    if (res.status === 401 || res.status === 403) {
      logout();
      return null;
    }
    const data = await res.json();
    return data;
  } catch (err) {
    console.error('API error:', err);
    // Network / server down
    return { success: false, message: 'Cannot connect to server. Make sure the backend is running on port 5000.' };
  }
}
