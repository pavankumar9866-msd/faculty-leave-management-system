// ============================================================
//  emailService.js  —  Nodemailer email notification module
//  Place this in:  backend/utils/emailService.js
// ============================================================

const nodemailer = require('nodemailer');

// ── Transporter ──────────────────────────────────────────────
// Uses env vars from backend/.env (see setup below)
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,            // true for port 465, false for 587
  auth: {
    user: process.env.SMTP_USER,   // your Gmail / SMTP email
    pass: process.env.SMTP_PASS,   // Gmail App Password (not account password)
  },
});

// ── Verify connection on startup (optional, logs to console) ─
transporter.verify((err) => {
  if (err) console.error('❌ Email transporter error:', err.message);
  else     console.log('✅ Email transporter ready');
});


// ════════════════════════════════════════════════════════════
//  1. ADMIN NOTIFICATION — faculty applied for leave
//     Call this right after inserting a new leave application
// ════════════════════════════════════════════════════════════
async function notifyAdminNewLeave({ adminEmail, adminName, faculty, leave }) {
  const { name, faculty_id, department } = faculty;
  const { leave_type, from_date, to_date, total_days, reason, applied_at } = leave;

  const fmt = (d) =>
    new Date(d).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    });

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f7fb; margin: 0; padding: 0; }
    .wrap { max-width: 560px; margin: 30px auto; background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
    .header { background: linear-gradient(135deg, #1abc9c, #16a085); padding: 28px 32px; text-align: center; }
    .header h1 { color: #fff; margin: 0; font-size: 20px; font-weight: 700; }
    .header p  { color: rgba(255,255,255,.85); margin: 6px 0 0; font-size: 13px; }
    .body { padding: 28px 32px; }
    .badge { display: inline-block; background: #fff3cd; color: #856404; border: 1px solid #ffc107; border-radius: 20px; padding: 4px 14px; font-size: 12px; font-weight: 700; margin-bottom: 18px; }
    .info-box { background: #f7faff; border-left: 4px solid #1abc9c; border-radius: 8px; padding: 14px 18px; margin-bottom: 18px; }
    .info-box .row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; border-bottom: 1px solid #eef1f8; }
    .info-box .row:last-child { border-bottom: none; }
    .info-box .row .lbl { color: #7a8499; font-weight: 600; }
    .info-box .row .val { color: #1a1f36; font-weight: 700; }
    .reason-box { background: #fffbf0; border: 1px solid #ffe08a; border-radius: 8px; padding: 12px 16px; font-size: 13px; color: #5a4a00; margin-bottom: 22px; }
    .reason-box b { display: block; margin-bottom: 4px; color: #856404; }
    .cta { text-align: center; margin-bottom: 24px; }
    .cta a { background: #1abc9c; color: #fff; text-decoration: none; padding: 12px 30px; border-radius: 8px; font-weight: 700; font-size: 14px; display: inline-block; }
    .footer { background: #f4f7fb; text-align: center; padding: 14px; font-size: 11px; color: #aaa; }
  </style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h1>📋 New Leave Application</h1>
    <p>A faculty member has submitted a leave request</p>
  </div>
  <div class="body">
    <span class="badge">⏳ Pending Review</span>
    <p style="color:#1a1f36;font-size:14px;margin-top:0">
      Hello <b>${adminName || 'Admin'}</b>, a new leave application has been submitted and requires your attention.
    </p>

    <div class="info-box">
      <div class="row"><span class="lbl">Faculty Name</span><span class="val">${name}</span></div>
      <div class="row"><span class="lbl">Faculty ID</span><span class="val">${faculty_id}</span></div>
      <div class="row"><span class="lbl">Department</span><span class="val">${department || '—'}</span></div>
      <div class="row"><span class="lbl">Leave Type</span><span class="val">${leave_type}</span></div>
      <div class="row"><span class="lbl">From</span><span class="val">${fmt(from_date)}</span></div>
      <div class="row"><span class="lbl">To</span><span class="val">${fmt(to_date)}</span></div>
      <div class="row"><span class="lbl">Total Days</span><span class="val">${total_days} day${total_days > 1 ? 's' : ''}</span></div>
      <div class="row"><span class="lbl">Applied On</span><span class="val">${fmt(applied_at || new Date())}</span></div>
    </div>

    <div class="reason-box">
      <b>Reason for Leave:</b>
      ${reason}
    </div>

    <div class="cta">
      <a href="${process.env.FRONTEND_URL || 'http://localhost:5500'}/admin-dashboard.html">
        Review Application →
      </a>
    </div>

    <p style="font-size:12px;color:#aaa;text-align:center">
      Log in to the Admin Dashboard to approve or reject this request.
    </p>
  </div>
  <div class="footer">Faculty Leave Management System · This is an automated notification</div>
</div>
</body>
</html>`;

  await transporter.sendMail({
    from: `"Leave Portal" <${process.env.SMTP_USER}>`,
    to: adminEmail,
    subject: `📋 New Leave Request – ${name} (${leave_type}, ${total_days}d)`,
    html,
  });

  console.log(`📧 Admin notified at ${adminEmail} — leave by ${name}`);
}


// ════════════════════════════════════════════════════════════
//  2. FACULTY NOTIFICATION — leave approved / rejected
//     (already likely exists; included here for completeness)
// ════════════════════════════════════════════════════════════
async function notifyFacultyDecision({ facultyEmail, facultyName, leave, status, remarks, reviewedBy }) {
  const { leave_type, from_date, to_date, total_days } = leave;
  const approved = status === 'Approved';

  const fmt = (d) =>
    new Date(d).toLocaleDateString('en-IN', {
      day: '2-digit', month: 'short', year: 'numeric',
    });

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f4f7fb; margin: 0; padding: 0; }
    .wrap { max-width: 520px; margin: 30px auto; background: #fff; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,.08); }
    .header { background: ${approved ? 'linear-gradient(135deg,#27ae60,#1e8449)' : 'linear-gradient(135deg,#e74c3c,#c0392b)'}; padding: 28px 32px; text-align: center; }
    .header h1 { color: #fff; margin: 0; font-size: 20px; }
    .header p  { color: rgba(255,255,255,.85); margin: 6px 0 0; font-size: 13px; }
    .body { padding: 28px 32px; }
    .info-box { background: #f7faff; border-left: 4px solid ${approved ? '#27ae60' : '#e74c3c'}; border-radius: 8px; padding: 14px 18px; margin-bottom: 18px; }
    .info-box .row { display: flex; justify-content: space-between; padding: 5px 0; font-size: 13px; border-bottom: 1px solid #eef1f8; }
    .info-box .row:last-child { border-bottom: none; }
    .info-box .row .lbl { color: #7a8499; font-weight: 600; }
    .info-box .row .val { color: #1a1f36; font-weight: 700; }
    .remarks { background: #f9f9f9; border-radius: 8px; padding: 12px 16px; font-size: 13px; color: #555; margin-bottom: 20px; }
    .footer { background: #f4f7fb; text-align: center; padding: 14px; font-size: 11px; color: #aaa; }
  </style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h1>${approved ? '✅ Leave Approved' : '❌ Leave Rejected'}</h1>
    <p>Your leave application has been reviewed</p>
  </div>
  <div class="body">
    <p style="font-size:14px;color:#1a1f36">Hello <b>${facultyName}</b>,</p>
    <p style="font-size:13px;color:#555">Your leave application has been <b>${status.toLowerCase()}</b> by <b>${reviewedBy}</b>.</p>
    <div class="info-box">
      <div class="row"><span class="lbl">Leave Type</span><span class="val">${leave_type}</span></div>
      <div class="row"><span class="lbl">From</span><span class="val">${fmt(from_date)}</span></div>
      <div class="row"><span class="lbl">To</span><span class="val">${fmt(to_date)}</span></div>
      <div class="row"><span class="lbl">Total Days</span><span class="val">${total_days}</span></div>
      <div class="row"><span class="lbl">Status</span><span class="val">${status}</span></div>
    </div>
    ${remarks ? `<div class="remarks"><b>Admin Remarks:</b><br>${remarks}</div>` : ''}
    <p style="font-size:12px;color:#aaa;text-align:center">Check your dashboard for full details.</p>
  </div>
  <div class="footer">Faculty Leave Management System · Automated notification</div>
</div>
</body>
</html>`;

  await transporter.sendMail({
    from: `"Leave Portal" <${process.env.SMTP_USER}>`,
    to: facultyEmail,
    subject: `${approved ? '✅ Leave Approved' : '❌ Leave Rejected'} – ${leave_type} (${fmt(from_date)} – ${fmt(to_date)})`,
    html,
  });

  console.log(`📧 Faculty notified at ${facultyEmail} — ${status}`);
}


module.exports = { notifyAdminNewLeave, notifyFacultyDecision };